import { Component, OnInit, ViewChild } from '@angular/core';
import { IUserRegistration } from './user.interface';
import { UserService } from './user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit { 

  alert:boolean=false;
  registrations:IUserRegistration[];
  constructor(private registrationservice:UserService) { }

  ngOnInit(): void {
  }
  onClickSubmit(registration:IUserRegistration){

    this.registrationservice.addUser(registration);
    this.alert=true;
    console.log(registration);
    

  }

}
