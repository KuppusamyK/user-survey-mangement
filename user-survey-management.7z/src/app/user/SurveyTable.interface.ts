export interface IsurveyTable{
    title:string;
    description:string;
    city:string;
    state:string;
    country:string;
    ZIPcode:number;
    surveyDate:string;

}