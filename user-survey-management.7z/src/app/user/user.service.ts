import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { IUserRegistration } from './user.interface';
import { IsurveyTable } from './SurveyTable.interface';
import { ILoginUser } from './login.interface';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userRegistration: IUserRegistration[];
  surveytable: IsurveyTable[];
  loginUser:ILoginUser[];

  constructor(private http: HttpClient) {
    this.http.get<IUserRegistration[]>("assets/Registration.json")
      .subscribe(data => this.userRegistration = data, error => console.log(error));
    this.http.get<IsurveyTable[]>("assets/Survey.json")
      .subscribe(data => this.surveytable = data, error => console.log(error));
      this.http.get<ILoginUser[]>("assets/Login.json")
      .subscribe(data => this.loginUser = data, error => console.log(error));

  }
  getSurvey(): IsurveyTable[] {
    return this.surveytable;
    
  }

  addUser(user: IUserRegistration) {
    this.userRegistration.push(user);
    console.log(user);

  }
  addsurvey(usersurvey: IsurveyTable) {
    this.surveytable.push(usersurvey);
    console.log(this.surveytable)

  } 
  addlogin(login:ILoginUser){ 
    this.loginUser.push(login);
    console.log(login)

  }
  updateProfile(){

  }

}
