export interface IUpdateprofile{
    firstname:string;
    lastname:string;
    emailid:string;
    mobile:string;
    password:string;
}