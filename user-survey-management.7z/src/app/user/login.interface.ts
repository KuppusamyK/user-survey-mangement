export interface ILoginUser{
    emailid:string;
    password:string;
}