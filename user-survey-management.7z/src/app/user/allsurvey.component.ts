import { Component, OnInit } from '@angular/core';
import { IsurveyTable } from './SurveyTable.interface';
import { UserService } from './user.service';

@Component({
  selector: 'app-allsurvey',
  templateUrl: './allsurvey.component.html',
  styleUrls: ['./allsurvey.component.css']
})
export class AllsurveyComponent implements OnInit {

  surveytables: IsurveyTable[];
  constructor(private UserService: UserService) { }

  ngOnInit() {
    setTimeout(() => {
      this.surveytables = this.UserService.getSurvey();
    }, 10);

  }
  onSubmit(usersurvey: IsurveyTable) {
    this.UserService.addsurvey(usersurvey);
    this.surveytables=this.UserService.getSurvey();

  }

}
