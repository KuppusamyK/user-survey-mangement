export interface IUserRegistration{
        Firstname:string;
        Lastname:string;
        Emailid:string;
        Mobile:number;
        Password:string;
}