import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ILoginUser } from './login.interface';
import { UserService } from './user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginuser:ILoginUser;
  constructor(private loginservice:UserService,
    private router:Router) { }

  ngOnInit(): void {
  }
  onClickSubmit(login:ILoginUser){
    this.loginservice.addlogin(login)
    this.router.navigate(["/profile"])
  }
}
