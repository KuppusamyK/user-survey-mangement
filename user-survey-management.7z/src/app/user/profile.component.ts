import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUpdateprofile } from './Updateprofile.interface';
import { UserService } from './user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  updateprofile: IUpdateprofile[];
  alert:boolean=false;
  constructor(private router: Router,
    private usersurvey: UserService) { }

  ngOnInit(): void {
  }

  onClickSubmit(update: IUpdateprofile) {
    this.usersurvey.updateProfile();
    this.alert=true;
    console.log(update)

  }
  onClick() {
    this.router.navigate(["/allSurvey"]);
  }

}
