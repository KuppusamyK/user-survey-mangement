import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from "@angular/common/http";


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './user/registration.component';
import { LoginComponent } from './user/login.component';
import { ProfileComponent } from './user/profile.component';
import { AllsurveyComponent } from './user/allsurvey.component';
import { FormsModule } from '@angular/forms';
import { from } from 'rxjs';
import { HomepageComponent } from './user/homepage/homepage.component';


@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    ProfileComponent,
    AllsurveyComponent,
    HomepageComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
