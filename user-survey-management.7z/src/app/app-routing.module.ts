import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllsurveyComponent } from './user/allsurvey.component';
import { HomepageComponent } from './user/homepage/homepage.component';
import { LoginComponent } from './user/login.component';
import { ProfileComponent } from './user/profile.component';
import { RegistrationComponent } from './user/registration.component';

const routes: Routes = [
  {path:'registration',component:RegistrationComponent  },
  {path:'allSurvey',component:AllsurveyComponent},
  {path:'',component:HomepageComponent},
  {path:'login',component:LoginComponent},
  {path:'profile',component:ProfileComponent},

  //{path:'',redirectTo:'/registration',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
